package com.example.belajar_http

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
